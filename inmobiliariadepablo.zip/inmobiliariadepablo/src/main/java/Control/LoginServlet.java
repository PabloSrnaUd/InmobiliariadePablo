package Control;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String username = request.getParameter("username");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Inmobiliaria</title>");    
            out.println("<link rel=\"stylesheet\" href=\"" + request.getContextPath() + "/css/styles-servlet.css\">");
            out.println("</head>");
            out.println("<body>");
            
            out.println("<h1>Bienvenido, " + username + "!<br><br>Qué propiedad quieres adquirir?</h1>");
            
            out.println("<form action=\"LoginServlet\" method=\"post\">");
            out.println("<button id=\"casa1\" type=\"submit\" name=\"property\" value=\"Casa #1\">Casa #1<br>Dimensiones: 300m<sup>2</sup><br>3 Baños<br>7 Habitaciones<br>Piscina de 50m<sup>3</sup><br>Precio: COP$1B <br><br></button><br><br>");
            out.println("<button id=\"casa2\" type=\"submit\" name=\"property\" value=\"Casa #2\">Casa #2<br>Dimensiones: 200m<sup>2</sup><br>2 Baños<br>5 Habitaciones<br>Piscina de 40m<sup>3</sup><br>Precio: USD$700,000 <br><br></button><br><br>");
            out.println("<button id=\"casa3\" type=\"submit\" name=\"property\" value=\"Casa #3\">Casa #3<br>Dimensiones: 220m<sup>2</sup><br>4 Baños<br>6 Habitaciones<br>Piscina de 40m<sup>3</sup><br>Precio: EUR$800,000<br><br></button><br><br>");
            out.println("<input type=\"hidden\" name=\"username\" value=\"" + username + "\">");
            out.println("</form>");
            
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String property = request.getParameter("property");
        String username = request.getParameter("username");
        
        if (property != null) {
            switch (property) {
                case "Casa #1":
                    response.sendRedirect("CasaUno?username=" + username);
                    break;
                case "Casa #2":
                    response.sendRedirect("CasaDos?username=" + username);
                    break;
                case "Casa #3":
                    response.sendRedirect("CasaTres?username=" + username);
                    break;
                default:
                    response.sendRedirect("login.jsp"); // O algún manejo de error
                    break;
            }
        } else {
            processRequest(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
