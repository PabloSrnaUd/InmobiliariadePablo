package Modelo;

public class Inmueble {
    private int id;
    private String tipo;
    private String ubicacion;
    private double precio;
    private Usuario propietario; // Cambiado el tipo a Usuario

    // Constructor
    public Inmueble(String tipo, String ubicacion, double precio, Usuario propietario) {
        this.tipo = tipo;
        this.ubicacion = ubicacion;
        this.precio = precio;
        this.propietario = propietario;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Usuario getPropietario() {
        return propietario;
    }

    public void setPropietario(Usuario propietario) {
        this.propietario = propietario;
    }

    // Método para obtener el ID del propietario a través del objeto Usuario
    public int getIdPropietario() {
        return propietario.getId();
    }
}
