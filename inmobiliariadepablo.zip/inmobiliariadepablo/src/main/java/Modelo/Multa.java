package Modelo;

import java.util.Date;

public class Multa {
    private int idMulta;
    private int idUsuario;
    private String motivo;
    private double monto;
    private Date fecha;

    // Constructor
    public Multa(int idUsuario, String motivo, double monto, Date fecha) {
        this.idUsuario = idUsuario;
        this.motivo = motivo;
        this.monto = monto;
        this.fecha = fecha;
    }

    // Getters y Setters
    public int getIdMulta() {
        return idMulta;
    }

    public void setIdMulta(int idMulta) {
        this.idMulta = idMulta;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
