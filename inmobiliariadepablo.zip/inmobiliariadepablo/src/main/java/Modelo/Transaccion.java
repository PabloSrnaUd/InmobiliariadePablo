package Modelo;

import java.util.Date;

public class Transaccion {
    private int idUsuario;
    private String tipo; // Tipo de transacción: compra-venta, subasta, etc.
    private String descripcion;
    private Date fecha;
    private double monto;

    // Constructor
    public Transaccion(int idUsuario, String tipo, String descripcion, Date fecha, double monto) {
        this.idUsuario = idUsuario;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.fecha = fecha;
        this.monto = monto;
    }

    // Getters y Setters
    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }
}
